<?php

/* :picture:show.html.twig */
class __TwigTemplate_3327c6db8c5bd8a90ac6338ca68dce3d4808b865f0214d197ce4e2d0a065bf4d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":picture:show.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        // line 4
        echo "    <div class=\"container\">
        <div class=\"row\">
            <h1>
                <span>Picture</span>
                <a href=\"";
        // line 8
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_index");
        echo "\" class=\"btn btn-default pull-right d-inline-block\">Back to the list</a>
            </h1>
            <br>

            <div class=\"col-md-6\">
                <img src=\"";
        // line 13
        echo twig_escape_filter($this->env, ((($context["image_path"] ?? null) . "/") . twig_get_attribute($this->env, $this->getSourceContext(), ($context["picture"] ?? null), "imageName", array())), "html", null, true);
        echo "\" alt=\"Lights\" style=\"width:100%\">
            </div>

            <div class=\"col-md-6 form-group\">
                ";
        // line 17
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["edit_form"] ?? null), 'form_start');
        echo "
                ";
        // line 18
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["edit_form"] ?? null), 'widget');
        echo "
                <input type=\"submit\" class=\"btn btn-info\" value=\"Save changes\" />
                ";
        // line 20
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["edit_form"] ?? null), 'form_end');
        echo "

                <p align=\"right\">";
        // line 22
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), ($context["picture"] ?? null), "postedAt", array()), "Y-m-d H:i:s"), "html", null, true);
        echo "</p>
            </div>
            ";
        // line 24
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["delete_form"] ?? null), 'form_start');
        echo "
            <input type=\"submit\" class=\"btn btn-danger pull-right\" value=\"Delete\">
            ";
        // line 26
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["delete_form"] ?? null), 'form_end');
        echo "
        </div>


    </div>
";
    }

    public function getTemplateName()
    {
        return ":picture:show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  76 => 26,  71 => 24,  66 => 22,  61 => 20,  56 => 18,  52 => 17,  45 => 13,  37 => 8,  31 => 4,  28 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", ":picture:show.html.twig", "C:\\Users\\Public\\Desktop\\online_gallery (Symfony 3 server side)\\app/Resources\\views/picture/show.html.twig");
    }
}
