<?php

/* :picture:index.html.twig */
class __TwigTemplate_af1c152ee5675ba08317a3da1cbf20f6fccdfe5ca987ccf3047ab03dce9de831 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":picture:index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        // line 4
        echo "
    <div class=\"container\">
        <div class=\"row\">
            <h1>
                <span>Gallery</span>
                <a href=\"";
        // line 9
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_new");
        echo "\" class=\"btn btn-default pull-right d-inline-block\">Create a new picture</a>
            </h1>
            <br>
            <div class=\"col-md-12\">
                <p>
                    <span>Sort by</span>
                    <a href=\"#\" id=\"sortByDate\" class=\"btn btn-default btn-xs\">date</a>
                    <a href=\"#\" id=\"sortBySize\" class=\"btn btn-default btn-xs\">size</a>
                </p>
            </div>
            <div id=\"gallery\">
                ";
        // line 20
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["pictures"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["p"]) {
            // line 21
            echo "                    <div class=\"col-md-4 picture\">
                        <div class=\"thumbnail\">
                            <a href=\"";
            // line 23
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_show", array("id" => twig_get_attribute($this->env, $this->getSourceContext(),             // line 24
$context["p"], "id", array()))), "html", null, true);
            // line 25
            echo "\">
                                <img src=\"";
            // line 26
            echo twig_escape_filter($this->env, ((($context["image_path"] ?? null) . "/") . twig_get_attribute($this->env, $this->getSourceContext(), $context["p"], "imageName", array())), "html", null, true);
            echo "\" alt=\"Lights\" style=\"width:100%\">
                                <div class=\"caption\">
                                    <p>";
            // line 28
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["p"], "comment", array()), "html", null, true);
            echo "</p>
                                    <p align=\"right\" class=\"time\">";
            // line 29
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["p"], "postedAt", array()), "Y-m-d H:i:s"), "html", null, true);
            echo "</p>
                                    <p hidden class=\"size\">";
            // line 30
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["p"], "imageSize", array()), "html", null, true);
            echo "</p>
                                </div>
                            </a>
                        </div>
                    </div>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['p'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 36
        echo "            </div>
        </div>
    </div>
";
    }

    // line 41
    public function block_javascripts($context, array $blocks = array())
    {
        // line 42
        echo "    <script>
        (function( \$ ) {
            order = \"\";
            \$.sortBy = function( elements, field) {
                if(order == \"DESC\")
                    order = \"ASC\";
                else
                    order = \"DESC\";
                var arr = [];
                elements.each(function() {
                    var obj = {},
                        \$el = \$( this ),
                        time = \$el.find( \".\"+field ).text(),
                        date = new Date( \$.trim( time ) ),
                        timestamp = date.getTime();

                    obj.html = \$el[0].outerHTML;
                    obj.time = timestamp;

                    arr.push( obj );
                });

                var sorted = arr.sort(function( a, b ) {

                    if( order == \"ASC\" ) {
                        return a.time > b.time;
                    } else {
                        return b.time > a.time;
                    }

                });
                return sorted;
            };

            \$(function() {
                var \$dateBtn = \$( \"#sortByDate\" ),
                    \$sizeBtn = \$( \"#sortBySize\" ),
                    \$content = \$( \"#gallery\" ),
                    \$elements = \$( \".picture\" );

                \$dateBtn.click(function() {
                    var elements = \$.sortBy( \$elements, \"time\");
                    var html = \"\";
                    for( var i = 0; i < elements.length; ++i ) {
                        html += elements[i].html;
                    }
                    \$content[0].innerHTML = html;
                    return false;

                });

                \$sizeBtn.click(function() {
                    var elements = \$.sortBy(\$elements, \"size\" );
                    var html = \"\";
                    for( var i = 0; i < elements.length; ++i ) {
                        html += elements[i].html;
                    }
                    \$content[0].innerHTML = html;
                    return false;
                });
            });

        })( jQuery );
    </script>
";
    }

    public function getTemplateName()
    {
        return ":picture:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  102 => 42,  99 => 41,  92 => 36,  80 => 30,  76 => 29,  72 => 28,  67 => 26,  64 => 25,  62 => 24,  61 => 23,  57 => 21,  53 => 20,  39 => 9,  32 => 4,  29 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", ":picture:index.html.twig", "C:\\Users\\Public\\Desktop\\online_gallery (Symfony 3 server side)\\app/Resources\\views/picture/index.html.twig");
    }
}
