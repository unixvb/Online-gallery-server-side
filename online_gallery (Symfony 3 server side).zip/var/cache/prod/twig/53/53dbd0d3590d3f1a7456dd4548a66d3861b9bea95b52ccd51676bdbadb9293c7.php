<?php

/* picture/new.html.twig */
class __TwigTemplate_b822adfe662ed832436b96b680b816cfc1388a91745ac0a7fd57a3b209d1c67f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "picture/new.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        // line 4
        echo "
    <div class=\"container\">
        <div class=\"row\">
            <h1>
                <span>Picture creation</span>
                <a href=\"";
        // line 9
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_index");
        echo "\" class=\"btn btn-default pull-right d-inline-block\">Back to the list</a>
            </h1>
            <br>

            ";
        // line 13
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? null), 'form_start');
        echo "
            ";
        // line 14
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(($context["form"] ?? null), 'widget');
        echo "

            <button type=\"submit\" class=\"btn btn-primary d-inline\">Create</button>
            ";
        // line 17
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? null), 'form_end');
        echo "

        </div>
    </div>
";
    }

    // line 23
    public function block_javascripts($context, array $blocks = array())
    {
        // line 24
        echo "    <script>
        \$(document).ready(function() {
            \$(':input[type=\"submit\"]').prop('disabled', true);
        });


        \$('#appbundle_picture_imageFile_file').bind('change', function() {

            var sFileName = this.files[0].name;
            var sFileExtension = sFileName.split('.')[sFileName.split('.').length - 1].toLowerCase();
            var iFileSize = this.files[0].size;

            if (!(sFileExtension === \"jpg\" || sFileExtension === \"jpeg\" || sFileExtension === \"png\") || iFileSize > 1048576)
                \$(':input[type=\"submit\"]').prop('disabled', true);
            else
                \$(':input[type=\"submit\"]').prop('disabled', false);
        });
    </script>
";
    }

    public function getTemplateName()
    {
        return "picture/new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  68 => 24,  65 => 23,  56 => 17,  50 => 14,  46 => 13,  39 => 9,  32 => 4,  29 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "picture/new.html.twig", "C:\\Users\\Public\\Desktop\\online_gallery (Symfony 3 server side)\\app\\Resources\\views\\picture\\new.html.twig");
    }
}
