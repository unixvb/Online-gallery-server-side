<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_833395d2f0f6d55f3bef7ba7fe89a6564a116ad5ab4193aa1b599ab6a3d7d133 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6e7bf0a300966b7525760fa60350d25f0c3355337ba532ff306c48ce4042a483 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6e7bf0a300966b7525760fa60350d25f0c3355337ba532ff306c48ce4042a483->enter($__internal_6e7bf0a300966b7525760fa60350d25f0c3355337ba532ff306c48ce4042a483_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_b9138181ccbbb4c2443591ef3cf55bddb5696788d46cfcaf1a7f83d43ac12516 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b9138181ccbbb4c2443591ef3cf55bddb5696788d46cfcaf1a7f83d43ac12516->enter($__internal_b9138181ccbbb4c2443591ef3cf55bddb5696788d46cfcaf1a7f83d43ac12516_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_6e7bf0a300966b7525760fa60350d25f0c3355337ba532ff306c48ce4042a483->leave($__internal_6e7bf0a300966b7525760fa60350d25f0c3355337ba532ff306c48ce4042a483_prof);

        
        $__internal_b9138181ccbbb4c2443591ef3cf55bddb5696788d46cfcaf1a7f83d43ac12516->leave($__internal_b9138181ccbbb4c2443591ef3cf55bddb5696788d46cfcaf1a7f83d43ac12516_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_e5f4035b7d03153ddf155a97748a1fac523609fda9762a97433bfe11a0ccf4ad = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e5f4035b7d03153ddf155a97748a1fac523609fda9762a97433bfe11a0ccf4ad->enter($__internal_e5f4035b7d03153ddf155a97748a1fac523609fda9762a97433bfe11a0ccf4ad_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_405172a1e87c95b822f1e55f7296d850d8d889318d4bb94425fb15298f99ae45 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_405172a1e87c95b822f1e55f7296d850d8d889318d4bb94425fb15298f99ae45->enter($__internal_405172a1e87c95b822f1e55f7296d850d8d889318d4bb94425fb15298f99ae45_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_405172a1e87c95b822f1e55f7296d850d8d889318d4bb94425fb15298f99ae45->leave($__internal_405172a1e87c95b822f1e55f7296d850d8d889318d4bb94425fb15298f99ae45_prof);

        
        $__internal_e5f4035b7d03153ddf155a97748a1fac523609fda9762a97433bfe11a0ccf4ad->leave($__internal_e5f4035b7d03153ddf155a97748a1fac523609fda9762a97433bfe11a0ccf4ad_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_a3e13f6ad5401c528995f9ddd8ec69873636646fd59581bfcdd9cabd212518aa = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a3e13f6ad5401c528995f9ddd8ec69873636646fd59581bfcdd9cabd212518aa->enter($__internal_a3e13f6ad5401c528995f9ddd8ec69873636646fd59581bfcdd9cabd212518aa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_914b3e4154d8256f3d92cc248a3b5b2c0db7f3f7603a3f67e3a05701337c6a3c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_914b3e4154d8256f3d92cc248a3b5b2c0db7f3f7603a3f67e3a05701337c6a3c->enter($__internal_914b3e4154d8256f3d92cc248a3b5b2c0db7f3f7603a3f67e3a05701337c6a3c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_914b3e4154d8256f3d92cc248a3b5b2c0db7f3f7603a3f67e3a05701337c6a3c->leave($__internal_914b3e4154d8256f3d92cc248a3b5b2c0db7f3f7603a3f67e3a05701337c6a3c_prof);

        
        $__internal_a3e13f6ad5401c528995f9ddd8ec69873636646fd59581bfcdd9cabd212518aa->leave($__internal_a3e13f6ad5401c528995f9ddd8ec69873636646fd59581bfcdd9cabd212518aa_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_582fa4bbacb15ff060bf8fdf8641b4a0f440e6ca1665ed8da3ff77630fbb4858 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_582fa4bbacb15ff060bf8fdf8641b4a0f440e6ca1665ed8da3ff77630fbb4858->enter($__internal_582fa4bbacb15ff060bf8fdf8641b4a0f440e6ca1665ed8da3ff77630fbb4858_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_7600998c500556e27e2ba7e6fbf0bff4f2b7feeec3ab02e98f844d5899ed7a47 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7600998c500556e27e2ba7e6fbf0bff4f2b7feeec3ab02e98f844d5899ed7a47->enter($__internal_7600998c500556e27e2ba7e6fbf0bff4f2b7feeec3ab02e98f844d5899ed7a47_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => (isset($context["token"]) || array_key_exists("token", $context) ? $context["token"] : (function () { throw new Twig_Error_Runtime('Variable "token" does not exist.', 13, $this->getSourceContext()); })()))));
        echo "
";
        
        $__internal_7600998c500556e27e2ba7e6fbf0bff4f2b7feeec3ab02e98f844d5899ed7a47->leave($__internal_7600998c500556e27e2ba7e6fbf0bff4f2b7feeec3ab02e98f844d5899ed7a47_prof);

        
        $__internal_582fa4bbacb15ff060bf8fdf8641b4a0f440e6ca1665ed8da3ff77630fbb4858->leave($__internal_582fa4bbacb15ff060bf8fdf8641b4a0f440e6ca1665ed8da3ff77630fbb4858_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "C:\\Users\\Public\\Desktop\\online_gallery (Symfony 3 server side)\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\router.html.twig");
    }
}
