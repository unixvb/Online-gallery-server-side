<?php

/* @WebProfiler/Collector/ajax.html.twig */
class __TwigTemplate_12e7f9fcd5236f6fec17060b1833a31aec3b63737fff9f7c3644982d6656f8a3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/ajax.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ae5c3fe2206009030e332abb2788cac00978238abd060b2e7a2d529b9970d061 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ae5c3fe2206009030e332abb2788cac00978238abd060b2e7a2d529b9970d061->enter($__internal_ae5c3fe2206009030e332abb2788cac00978238abd060b2e7a2d529b9970d061_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/ajax.html.twig"));

        $__internal_0a8de52c75a8c88a972ee91a572e9c38bcdc4800afa54b26bb143173a8322a4a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0a8de52c75a8c88a972ee91a572e9c38bcdc4800afa54b26bb143173a8322a4a->enter($__internal_0a8de52c75a8c88a972ee91a572e9c38bcdc4800afa54b26bb143173a8322a4a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/ajax.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_ae5c3fe2206009030e332abb2788cac00978238abd060b2e7a2d529b9970d061->leave($__internal_ae5c3fe2206009030e332abb2788cac00978238abd060b2e7a2d529b9970d061_prof);

        
        $__internal_0a8de52c75a8c88a972ee91a572e9c38bcdc4800afa54b26bb143173a8322a4a->leave($__internal_0a8de52c75a8c88a972ee91a572e9c38bcdc4800afa54b26bb143173a8322a4a_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_ff5e995da8192346872e58239b229b0b9d711033c408ab9f1ad87c179c0f31a6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ff5e995da8192346872e58239b229b0b9d711033c408ab9f1ad87c179c0f31a6->enter($__internal_ff5e995da8192346872e58239b229b0b9d711033c408ab9f1ad87c179c0f31a6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_b2301c46f8972acbc4cc9edc8a954842ab939ac427db823aa1b6e320daebae2f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b2301c46f8972acbc4cc9edc8a954842ab939ac427db823aa1b6e320daebae2f->enter($__internal_b2301c46f8972acbc4cc9edc8a954842ab939ac427db823aa1b6e320daebae2f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        // line 4
        echo "    ";
        ob_start();
        // line 5
        echo "        ";
        echo twig_include($this->env, $context, "@WebProfiler/Icon/ajax.svg");
        echo "
        <span class=\"sf-toolbar-value sf-toolbar-ajax-request-counter\">0</span>
    ";
        $context["icon"] = ('' === $tmp = ob_get_clean()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        // line 8
        echo "
    ";
        // line 9
        $context["text"] = ('' === $tmp = "        <div class=\"sf-toolbar-info-piece\">
            <b class=\"sf-toolbar-ajax-info\"></b>
        </div>
        <div class=\"sf-toolbar-info-piece\">
            <table class=\"sf-toolbar-ajax-requests\">
                <thead>
                    <tr>
                        <th>Method</th>
                        <th>Type</th>
                        <th>Status</th>
                        <th>URL</th>
                        <th>Time</th>
                        <th>Profile</th>
                    </tr>
                </thead>
                <tbody class=\"sf-toolbar-ajax-request-list\"></tbody>
            </table>
        </div>
    ") ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        // line 29
        echo "
    ";
        // line 30
        echo twig_include($this->env, $context, "@WebProfiler/Profiler/toolbar_item.html.twig", array("link" => false));
        echo "
";
        
        $__internal_b2301c46f8972acbc4cc9edc8a954842ab939ac427db823aa1b6e320daebae2f->leave($__internal_b2301c46f8972acbc4cc9edc8a954842ab939ac427db823aa1b6e320daebae2f_prof);

        
        $__internal_ff5e995da8192346872e58239b229b0b9d711033c408ab9f1ad87c179c0f31a6->leave($__internal_ff5e995da8192346872e58239b229b0b9d711033c408ab9f1ad87c179c0f31a6_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/ajax.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  85 => 30,  82 => 29,  62 => 9,  59 => 8,  52 => 5,  49 => 4,  40 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}
    {% set icon %}
        {{ include('@WebProfiler/Icon/ajax.svg') }}
        <span class=\"sf-toolbar-value sf-toolbar-ajax-request-counter\">0</span>
    {% endset %}

    {% set text %}
        <div class=\"sf-toolbar-info-piece\">
            <b class=\"sf-toolbar-ajax-info\"></b>
        </div>
        <div class=\"sf-toolbar-info-piece\">
            <table class=\"sf-toolbar-ajax-requests\">
                <thead>
                    <tr>
                        <th>Method</th>
                        <th>Type</th>
                        <th>Status</th>
                        <th>URL</th>
                        <th>Time</th>
                        <th>Profile</th>
                    </tr>
                </thead>
                <tbody class=\"sf-toolbar-ajax-request-list\"></tbody>
            </table>
        </div>
    {% endset %}

    {{ include('@WebProfiler/Profiler/toolbar_item.html.twig', { link: false }) }}
{% endblock %}
", "@WebProfiler/Collector/ajax.html.twig", "C:\\Users\\Public\\Desktop\\online_gallery (Symfony 3 server side)\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\ajax.html.twig");
    }
}
