<?php

/* picture/show.html.twig */
class __TwigTemplate_35134be000e7c0c576d684138e730959ae0ff23d8d774c0a84b6b9f02a7239a1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "picture/show.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_22881da12b58d1a183f95d8202bb46c3d28f4bb089f67b1bfc00133db32210cf = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_22881da12b58d1a183f95d8202bb46c3d28f4bb089f67b1bfc00133db32210cf->enter($__internal_22881da12b58d1a183f95d8202bb46c3d28f4bb089f67b1bfc00133db32210cf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "picture/show.html.twig"));

        $__internal_10019722f578d8855aeb3ceffe4cbe331bc505c6c713872775c9374ea74052e0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_10019722f578d8855aeb3ceffe4cbe331bc505c6c713872775c9374ea74052e0->enter($__internal_10019722f578d8855aeb3ceffe4cbe331bc505c6c713872775c9374ea74052e0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "picture/show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_22881da12b58d1a183f95d8202bb46c3d28f4bb089f67b1bfc00133db32210cf->leave($__internal_22881da12b58d1a183f95d8202bb46c3d28f4bb089f67b1bfc00133db32210cf_prof);

        
        $__internal_10019722f578d8855aeb3ceffe4cbe331bc505c6c713872775c9374ea74052e0->leave($__internal_10019722f578d8855aeb3ceffe4cbe331bc505c6c713872775c9374ea74052e0_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_d9aebd3433fe504ca26da1ed806d8c2e8e17c0150d8b47ddddaeef11d0ec5831 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d9aebd3433fe504ca26da1ed806d8c2e8e17c0150d8b47ddddaeef11d0ec5831->enter($__internal_d9aebd3433fe504ca26da1ed806d8c2e8e17c0150d8b47ddddaeef11d0ec5831_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_f27a1bb6d27bd85c1efe26a67a393fa24e5e08cfe44e632ad8d83997734dd584 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f27a1bb6d27bd85c1efe26a67a393fa24e5e08cfe44e632ad8d83997734dd584->enter($__internal_f27a1bb6d27bd85c1efe26a67a393fa24e5e08cfe44e632ad8d83997734dd584_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <div class=\"container\">
        <div class=\"row\">
            <h1>
                <span>Picture</span>
                <a href=\"";
        // line 8
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_index");
        echo "\" class=\"btn btn-default pull-right d-inline-block\">Back to the list</a>
            </h1>
            <br>

            <div class=\"col-md-6\">
                <img src=\"";
        // line 13
        echo twig_escape_filter($this->env, (((isset($context["image_path"]) || array_key_exists("image_path", $context) ? $context["image_path"] : (function () { throw new Twig_Error_Runtime('Variable "image_path" does not exist.', 13, $this->getSourceContext()); })()) . "/") . twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["picture"]) || array_key_exists("picture", $context) ? $context["picture"] : (function () { throw new Twig_Error_Runtime('Variable "picture" does not exist.', 13, $this->getSourceContext()); })()), "imageName", array())), "html", null, true);
        echo "\" alt=\"Lights\" style=\"width:100%\">
            </div>

            <div class=\"col-md-6 form-group\">
                ";
        // line 17
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["edit_form"]) || array_key_exists("edit_form", $context) ? $context["edit_form"] : (function () { throw new Twig_Error_Runtime('Variable "edit_form" does not exist.', 17, $this->getSourceContext()); })()), 'form_start');
        echo "
                ";
        // line 18
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock((isset($context["edit_form"]) || array_key_exists("edit_form", $context) ? $context["edit_form"] : (function () { throw new Twig_Error_Runtime('Variable "edit_form" does not exist.', 18, $this->getSourceContext()); })()), 'widget');
        echo "
                <input type=\"submit\" class=\"btn btn-info\" value=\"Save changes\" />
                ";
        // line 20
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["edit_form"]) || array_key_exists("edit_form", $context) ? $context["edit_form"] : (function () { throw new Twig_Error_Runtime('Variable "edit_form" does not exist.', 20, $this->getSourceContext()); })()), 'form_end');
        echo "

                <p align=\"right\">";
        // line 22
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["picture"]) || array_key_exists("picture", $context) ? $context["picture"] : (function () { throw new Twig_Error_Runtime('Variable "picture" does not exist.', 22, $this->getSourceContext()); })()), "postedAt", array()), "Y-m-d H:i:s"), "html", null, true);
        echo "</p>
            </div>
            ";
        // line 24
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["delete_form"]) || array_key_exists("delete_form", $context) ? $context["delete_form"] : (function () { throw new Twig_Error_Runtime('Variable "delete_form" does not exist.', 24, $this->getSourceContext()); })()), 'form_start');
        echo "
            <input type=\"submit\" class=\"btn btn-danger pull-right\" value=\"Delete\">
            ";
        // line 26
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["delete_form"]) || array_key_exists("delete_form", $context) ? $context["delete_form"] : (function () { throw new Twig_Error_Runtime('Variable "delete_form" does not exist.', 26, $this->getSourceContext()); })()), 'form_end');
        echo "
        </div>


    </div>
";
        
        $__internal_f27a1bb6d27bd85c1efe26a67a393fa24e5e08cfe44e632ad8d83997734dd584->leave($__internal_f27a1bb6d27bd85c1efe26a67a393fa24e5e08cfe44e632ad8d83997734dd584_prof);

        
        $__internal_d9aebd3433fe504ca26da1ed806d8c2e8e17c0150d8b47ddddaeef11d0ec5831->leave($__internal_d9aebd3433fe504ca26da1ed806d8c2e8e17c0150d8b47ddddaeef11d0ec5831_prof);

    }

    public function getTemplateName()
    {
        return "picture/show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 26,  89 => 24,  84 => 22,  79 => 20,  74 => 18,  70 => 17,  63 => 13,  55 => 8,  49 => 4,  40 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("    {% extends 'base.html.twig' %}

{% block body %}
    <div class=\"container\">
        <div class=\"row\">
            <h1>
                <span>Picture</span>
                <a href=\"{{ path('_index') }}\" class=\"btn btn-default pull-right d-inline-block\">Back to the list</a>
            </h1>
            <br>

            <div class=\"col-md-6\">
                <img src=\"{{ image_path ~ '/' ~ picture.imageName }}\" alt=\"Lights\" style=\"width:100%\">
            </div>

            <div class=\"col-md-6 form-group\">
                {{ form_start(edit_form) }}
                {{ form_widget(edit_form) }}
                <input type=\"submit\" class=\"btn btn-info\" value=\"Save changes\" />
                {{ form_end(edit_form) }}

                <p align=\"right\">{{ picture.postedAt|date('Y-m-d H:i:s') }}</p>
            </div>
            {{ form_start(delete_form) }}
            <input type=\"submit\" class=\"btn btn-danger pull-right\" value=\"Delete\">
            {{ form_end(delete_form) }}
        </div>


    </div>
{% endblock %}
", "picture/show.html.twig", "C:\\Users\\Public\\Desktop\\online_gallery (Symfony 3 server side)\\app\\Resources\\views\\picture\\show.html.twig");
    }
}
