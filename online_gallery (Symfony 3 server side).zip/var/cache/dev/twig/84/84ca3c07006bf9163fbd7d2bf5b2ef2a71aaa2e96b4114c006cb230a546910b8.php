<?php

/* picture/index.html.twig */
class __TwigTemplate_bfb8a4edb3d0d6295530d4341a9f6bc92617b3cc2b71a3e522fd19f2e254a640 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "picture/index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e5b0157311342e63820168662e63d4e18ca9cba6c7e59c5f92963aac23541d79 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e5b0157311342e63820168662e63d4e18ca9cba6c7e59c5f92963aac23541d79->enter($__internal_e5b0157311342e63820168662e63d4e18ca9cba6c7e59c5f92963aac23541d79_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "picture/index.html.twig"));

        $__internal_6d6c6ac7084242ac50e6a99bd5e9250b95bace406cc581822b2f9904f7248f18 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6d6c6ac7084242ac50e6a99bd5e9250b95bace406cc581822b2f9904f7248f18->enter($__internal_6d6c6ac7084242ac50e6a99bd5e9250b95bace406cc581822b2f9904f7248f18_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "picture/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_e5b0157311342e63820168662e63d4e18ca9cba6c7e59c5f92963aac23541d79->leave($__internal_e5b0157311342e63820168662e63d4e18ca9cba6c7e59c5f92963aac23541d79_prof);

        
        $__internal_6d6c6ac7084242ac50e6a99bd5e9250b95bace406cc581822b2f9904f7248f18->leave($__internal_6d6c6ac7084242ac50e6a99bd5e9250b95bace406cc581822b2f9904f7248f18_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_1a2c2219b82aba1500a47711fae2f32d15667bed4f57ea3c37f97e17881820d4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1a2c2219b82aba1500a47711fae2f32d15667bed4f57ea3c37f97e17881820d4->enter($__internal_1a2c2219b82aba1500a47711fae2f32d15667bed4f57ea3c37f97e17881820d4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_45bfae954fd848802b90223ef7f55d80f3be7df60ab57b07ce779c3cfcb36d87 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_45bfae954fd848802b90223ef7f55d80f3be7df60ab57b07ce779c3cfcb36d87->enter($__internal_45bfae954fd848802b90223ef7f55d80f3be7df60ab57b07ce779c3cfcb36d87_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "
    <div class=\"container\">
        <div class=\"row\">
            <h1>
                <span>Gallery</span>
                <a href=\"";
        // line 9
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_new");
        echo "\" class=\"btn btn-default pull-right d-inline-block\">Create a new picture</a>
            </h1>
            <br>
            <div class=\"col-md-12\">
                <p>
                    <span>Sort by</span>
                    <a href=\"#\" id=\"sortByDate\" class=\"btn btn-default btn-xs\">date</a>
                    <a href=\"#\" id=\"sortBySize\" class=\"btn btn-default btn-xs\">size</a>
                </p>
            </div>
            <div id=\"gallery\">
                ";
        // line 20
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["pictures"]) || array_key_exists("pictures", $context) ? $context["pictures"] : (function () { throw new Twig_Error_Runtime('Variable "pictures" does not exist.', 20, $this->getSourceContext()); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["p"]) {
            // line 21
            echo "                    <div class=\"col-md-4 picture\">
                        <div class=\"thumbnail\">
                            <a href=\"";
            // line 23
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_show", array("id" => twig_get_attribute($this->env, $this->getSourceContext(),             // line 24
$context["p"], "id", array()))), "html", null, true);
            // line 25
            echo "\">
                                <img src=\"";
            // line 26
            echo twig_escape_filter($this->env, (((isset($context["image_path"]) || array_key_exists("image_path", $context) ? $context["image_path"] : (function () { throw new Twig_Error_Runtime('Variable "image_path" does not exist.', 26, $this->getSourceContext()); })()) . "/") . twig_get_attribute($this->env, $this->getSourceContext(), $context["p"], "imageName", array())), "html", null, true);
            echo "\" alt=\"Lights\" style=\"width:100%\">
                                <div class=\"caption\">
                                    <p>";
            // line 28
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["p"], "comment", array()), "html", null, true);
            echo "</p>
                                    <p align=\"right\" class=\"time\">";
            // line 29
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["p"], "postedAt", array()), "Y-m-d H:i:s"), "html", null, true);
            echo "</p>
                                    <p hidden class=\"size\">";
            // line 30
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["p"], "imageSize", array()), "html", null, true);
            echo "</p>
                                </div>
                            </a>
                        </div>
                    </div>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['p'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 36
        echo "            </div>
        </div>
    </div>
";
        
        $__internal_45bfae954fd848802b90223ef7f55d80f3be7df60ab57b07ce779c3cfcb36d87->leave($__internal_45bfae954fd848802b90223ef7f55d80f3be7df60ab57b07ce779c3cfcb36d87_prof);

        
        $__internal_1a2c2219b82aba1500a47711fae2f32d15667bed4f57ea3c37f97e17881820d4->leave($__internal_1a2c2219b82aba1500a47711fae2f32d15667bed4f57ea3c37f97e17881820d4_prof);

    }

    // line 41
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_b7fce6e2f740ddafa60f9f4e938f1b423f5ac97dc62d93ec86ebb946286a1a5f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b7fce6e2f740ddafa60f9f4e938f1b423f5ac97dc62d93ec86ebb946286a1a5f->enter($__internal_b7fce6e2f740ddafa60f9f4e938f1b423f5ac97dc62d93ec86ebb946286a1a5f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_02cbd31a2ad14ec9800623b52c0bcde3ff8fef0fbcad53dc7e6f4cd9fbf5d710 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_02cbd31a2ad14ec9800623b52c0bcde3ff8fef0fbcad53dc7e6f4cd9fbf5d710->enter($__internal_02cbd31a2ad14ec9800623b52c0bcde3ff8fef0fbcad53dc7e6f4cd9fbf5d710_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 42
        echo "    <script>
        (function( \$ ) {
            order = \"\";
            \$.sortBy = function( elements, field) {
                if(order == \"DESC\")
                    order = \"ASC\";
                else
                    order = \"DESC\";
                var arr = [];
                elements.each(function() {
                    var obj = {},
                        \$el = \$( this ),
                        time = \$el.find( \".\"+field ).text(),
                        date = new Date( \$.trim( time ) ),
                        timestamp = date.getTime();

                    obj.html = \$el[0].outerHTML;
                    obj.time = timestamp;

                    arr.push( obj );
                });

                var sorted = arr.sort(function( a, b ) {

                    if( order == \"ASC\" ) {
                        return a.time > b.time;
                    } else {
                        return b.time > a.time;
                    }

                });
                return sorted;
            };

            \$(function() {
                var \$dateBtn = \$( \"#sortByDate\" ),
                    \$sizeBtn = \$( \"#sortBySize\" ),
                    \$content = \$( \"#gallery\" ),
                    \$elements = \$( \".picture\" );

                \$dateBtn.click(function() {
                    var elements = \$.sortBy( \$elements, \"time\");
                    var html = \"\";
                    for( var i = 0; i < elements.length; ++i ) {
                        html += elements[i].html;
                    }
                    \$content[0].innerHTML = html;
                    return false;

                });

                \$sizeBtn.click(function() {
                    var elements = \$.sortBy(\$elements, \"size\" );
                    var html = \"\";
                    for( var i = 0; i < elements.length; ++i ) {
                        html += elements[i].html;
                    }
                    \$content[0].innerHTML = html;
                    return false;
                });
            });

        })( jQuery );
    </script>
";
        
        $__internal_02cbd31a2ad14ec9800623b52c0bcde3ff8fef0fbcad53dc7e6f4cd9fbf5d710->leave($__internal_02cbd31a2ad14ec9800623b52c0bcde3ff8fef0fbcad53dc7e6f4cd9fbf5d710_prof);

        
        $__internal_b7fce6e2f740ddafa60f9f4e938f1b423f5ac97dc62d93ec86ebb946286a1a5f->leave($__internal_b7fce6e2f740ddafa60f9f4e938f1b423f5ac97dc62d93ec86ebb946286a1a5f_prof);

    }

    public function getTemplateName()
    {
        return "picture/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  132 => 42,  123 => 41,  110 => 36,  98 => 30,  94 => 29,  90 => 28,  85 => 26,  82 => 25,  80 => 24,  79 => 23,  75 => 21,  71 => 20,  57 => 9,  50 => 4,  41 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}

    <div class=\"container\">
        <div class=\"row\">
            <h1>
                <span>Gallery</span>
                <a href=\"{{ path('_new') }}\" class=\"btn btn-default pull-right d-inline-block\">Create a new picture</a>
            </h1>
            <br>
            <div class=\"col-md-12\">
                <p>
                    <span>Sort by</span>
                    <a href=\"#\" id=\"sortByDate\" class=\"btn btn-default btn-xs\">date</a>
                    <a href=\"#\" id=\"sortBySize\" class=\"btn btn-default btn-xs\">size</a>
                </p>
            </div>
            <div id=\"gallery\">
                {% for p in pictures %}
                    <div class=\"col-md-4 picture\">
                        <div class=\"thumbnail\">
                            <a href=\"{{ path('_show', {
                                'id': p.id
                            }) }}\">
                                <img src=\"{{ image_path ~ '/' ~ p.imageName }}\" alt=\"Lights\" style=\"width:100%\">
                                <div class=\"caption\">
                                    <p>{{ p.comment }}</p>
                                    <p align=\"right\" class=\"time\">{{ p.postedAt|date('Y-m-d H:i:s') }}</p>
                                    <p hidden class=\"size\">{{ p.imageSize }}</p>
                                </div>
                            </a>
                        </div>
                    </div>
                {% endfor %}
            </div>
        </div>
    </div>
{% endblock %}

{% block javascripts %}
    <script>
        (function( \$ ) {
            order = \"\";
            \$.sortBy = function( elements, field) {
                if(order == \"DESC\")
                    order = \"ASC\";
                else
                    order = \"DESC\";
                var arr = [];
                elements.each(function() {
                    var obj = {},
                        \$el = \$( this ),
                        time = \$el.find( \".\"+field ).text(),
                        date = new Date( \$.trim( time ) ),
                        timestamp = date.getTime();

                    obj.html = \$el[0].outerHTML;
                    obj.time = timestamp;

                    arr.push( obj );
                });

                var sorted = arr.sort(function( a, b ) {

                    if( order == \"ASC\" ) {
                        return a.time > b.time;
                    } else {
                        return b.time > a.time;
                    }

                });
                return sorted;
            };

            \$(function() {
                var \$dateBtn = \$( \"#sortByDate\" ),
                    \$sizeBtn = \$( \"#sortBySize\" ),
                    \$content = \$( \"#gallery\" ),
                    \$elements = \$( \".picture\" );

                \$dateBtn.click(function() {
                    var elements = \$.sortBy( \$elements, \"time\");
                    var html = \"\";
                    for( var i = 0; i < elements.length; ++i ) {
                        html += elements[i].html;
                    }
                    \$content[0].innerHTML = html;
                    return false;

                });

                \$sizeBtn.click(function() {
                    var elements = \$.sortBy(\$elements, \"size\" );
                    var html = \"\";
                    for( var i = 0; i < elements.length; ++i ) {
                        html += elements[i].html;
                    }
                    \$content[0].innerHTML = html;
                    return false;
                });
            });

        })( jQuery );
    </script>
{% endblock %}", "picture/index.html.twig", "C:\\Users\\Public\\Desktop\\online_gallery (Symfony 3 server side)\\app\\Resources\\views\\picture\\index.html.twig");
    }
}
