<?php

/* base.html.twig */
class __TwigTemplate_c4a044bb2d844129eb86ee3c62903f9e689e06dba7c02517b1f1bf98fe39c218 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5a4ccdb1afb78becdcf86668e454e6d44ebc87319494e35c4b3e50fcaa3b79da = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5a4ccdb1afb78becdcf86668e454e6d44ebc87319494e35c4b3e50fcaa3b79da->enter($__internal_5a4ccdb1afb78becdcf86668e454e6d44ebc87319494e35c4b3e50fcaa3b79da_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_53833fd87f3aea50849df41dd07680268e5b607cb3cbabe7494fed80bb300c0c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_53833fd87f3aea50849df41dd07680268e5b607cb3cbabe7494fed80bb300c0c->enter($__internal_53833fd87f3aea50849df41dd07680268e5b607cb3cbabe7494fed80bb300c0c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "    <!DOCTYPE html>
<html>
<head>
    <meta charset=\"UTF-8\" />
    <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    <meta charset=\"utf-8\">
    ";
        // line 7
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 12
        echo "</head>
<body>
";
        // line 14
        $this->displayBlock('body', $context, $blocks);
        // line 15
        $this->displayBlock('javascripts', $context, $blocks);
        // line 16
        echo "</body>
</html>
";
        
        $__internal_5a4ccdb1afb78becdcf86668e454e6d44ebc87319494e35c4b3e50fcaa3b79da->leave($__internal_5a4ccdb1afb78becdcf86668e454e6d44ebc87319494e35c4b3e50fcaa3b79da_prof);

        
        $__internal_53833fd87f3aea50849df41dd07680268e5b607cb3cbabe7494fed80bb300c0c->leave($__internal_53833fd87f3aea50849df41dd07680268e5b607cb3cbabe7494fed80bb300c0c_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_dde05f232e865973d5046c65af92b3de1efd6380b7ce4d530262ce1d29f23497 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_dde05f232e865973d5046c65af92b3de1efd6380b7ce4d530262ce1d29f23497->enter($__internal_dde05f232e865973d5046c65af92b3de1efd6380b7ce4d530262ce1d29f23497_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_282eaaaca056db3eb969db878639361916d4c9cb9ac8eb358200b1e22ed5a053 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_282eaaaca056db3eb969db878639361916d4c9cb9ac8eb358200b1e22ed5a053->enter($__internal_282eaaaca056db3eb969db878639361916d4c9cb9ac8eb358200b1e22ed5a053_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Gallery";
        
        $__internal_282eaaaca056db3eb969db878639361916d4c9cb9ac8eb358200b1e22ed5a053->leave($__internal_282eaaaca056db3eb969db878639361916d4c9cb9ac8eb358200b1e22ed5a053_prof);

        
        $__internal_dde05f232e865973d5046c65af92b3de1efd6380b7ce4d530262ce1d29f23497->leave($__internal_dde05f232e865973d5046c65af92b3de1efd6380b7ce4d530262ce1d29f23497_prof);

    }

    // line 7
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_14ea831253653d97b1853fecfc45dc80b59507958a8aa0f3130b61139c49a680 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_14ea831253653d97b1853fecfc45dc80b59507958a8aa0f3130b61139c49a680->enter($__internal_14ea831253653d97b1853fecfc45dc80b59507958a8aa0f3130b61139c49a680_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_b3d3feea124117d088feabd73d34ec677cbbd2b36197c5899957e2a1ad5c0cee = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b3d3feea124117d088feabd73d34ec677cbbd2b36197c5899957e2a1ad5c0cee->enter($__internal_b3d3feea124117d088feabd73d34ec677cbbd2b36197c5899957e2a1ad5c0cee_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 8
        echo "        <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\">
        <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js\"></script>
        <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js\"></script>
    ";
        
        $__internal_b3d3feea124117d088feabd73d34ec677cbbd2b36197c5899957e2a1ad5c0cee->leave($__internal_b3d3feea124117d088feabd73d34ec677cbbd2b36197c5899957e2a1ad5c0cee_prof);

        
        $__internal_14ea831253653d97b1853fecfc45dc80b59507958a8aa0f3130b61139c49a680->leave($__internal_14ea831253653d97b1853fecfc45dc80b59507958a8aa0f3130b61139c49a680_prof);

    }

    // line 14
    public function block_body($context, array $blocks = array())
    {
        $__internal_179eb8f1dcde596c3a205b28a0a98504420dee2ca51ba38fda36d39b87e938ab = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_179eb8f1dcde596c3a205b28a0a98504420dee2ca51ba38fda36d39b87e938ab->enter($__internal_179eb8f1dcde596c3a205b28a0a98504420dee2ca51ba38fda36d39b87e938ab_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_3bed520b60fda131cddf1a18ca890b185d33942f3841d43603cc1cf18f2046ef = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3bed520b60fda131cddf1a18ca890b185d33942f3841d43603cc1cf18f2046ef->enter($__internal_3bed520b60fda131cddf1a18ca890b185d33942f3841d43603cc1cf18f2046ef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_3bed520b60fda131cddf1a18ca890b185d33942f3841d43603cc1cf18f2046ef->leave($__internal_3bed520b60fda131cddf1a18ca890b185d33942f3841d43603cc1cf18f2046ef_prof);

        
        $__internal_179eb8f1dcde596c3a205b28a0a98504420dee2ca51ba38fda36d39b87e938ab->leave($__internal_179eb8f1dcde596c3a205b28a0a98504420dee2ca51ba38fda36d39b87e938ab_prof);

    }

    // line 15
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_34458187e596afc6184a4edd248c31b3729ee532145527e5e861c97fc5506bac = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_34458187e596afc6184a4edd248c31b3729ee532145527e5e861c97fc5506bac->enter($__internal_34458187e596afc6184a4edd248c31b3729ee532145527e5e861c97fc5506bac_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_45862807a00fe9b13bc4cb2e16c4a3d785a439b9912913ab74051271b3b2ef52 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_45862807a00fe9b13bc4cb2e16c4a3d785a439b9912913ab74051271b3b2ef52->enter($__internal_45862807a00fe9b13bc4cb2e16c4a3d785a439b9912913ab74051271b3b2ef52_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_45862807a00fe9b13bc4cb2e16c4a3d785a439b9912913ab74051271b3b2ef52->leave($__internal_45862807a00fe9b13bc4cb2e16c4a3d785a439b9912913ab74051271b3b2ef52_prof);

        
        $__internal_34458187e596afc6184a4edd248c31b3729ee532145527e5e861c97fc5506bac->leave($__internal_34458187e596afc6184a4edd248c31b3729ee532145527e5e861c97fc5506bac_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  119 => 15,  102 => 14,  89 => 8,  80 => 7,  62 => 5,  50 => 16,  48 => 15,  46 => 14,  42 => 12,  40 => 7,  35 => 5,  29 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("    <!DOCTYPE html>
<html>
<head>
    <meta charset=\"UTF-8\" />
    <title>{% block title %}Gallery{% endblock %}</title>
    <meta charset=\"utf-8\">
    {% block stylesheets %}
        <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css\">
        <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js\"></script>
        <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js\"></script>
    {% endblock %}
</head>
<body>
{% block body %}{% endblock %}
{% block javascripts %}{% endblock %}
</body>
</html>
", "base.html.twig", "C:\\Users\\Public\\Desktop\\online_gallery (Symfony 3 server side)\\app\\Resources\\views\\base.html.twig");
    }
}
