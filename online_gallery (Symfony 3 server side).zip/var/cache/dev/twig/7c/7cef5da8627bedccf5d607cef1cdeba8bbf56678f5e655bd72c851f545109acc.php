<?php

/* picture/new.html.twig */
class __TwigTemplate_dcfa8848c133626df0516971dd81dd09654f4a90192674440a9f2a90085d5954 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "picture/new.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0b564f759003930c15ac2f543e81ef9a51308866334ef925000015c8a565a4c5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0b564f759003930c15ac2f543e81ef9a51308866334ef925000015c8a565a4c5->enter($__internal_0b564f759003930c15ac2f543e81ef9a51308866334ef925000015c8a565a4c5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "picture/new.html.twig"));

        $__internal_8d8a245f3c7db659dbc8542f8b70a57bd0e2ec0a1036bc93e8afb206d07cffa4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8d8a245f3c7db659dbc8542f8b70a57bd0e2ec0a1036bc93e8afb206d07cffa4->enter($__internal_8d8a245f3c7db659dbc8542f8b70a57bd0e2ec0a1036bc93e8afb206d07cffa4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "picture/new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_0b564f759003930c15ac2f543e81ef9a51308866334ef925000015c8a565a4c5->leave($__internal_0b564f759003930c15ac2f543e81ef9a51308866334ef925000015c8a565a4c5_prof);

        
        $__internal_8d8a245f3c7db659dbc8542f8b70a57bd0e2ec0a1036bc93e8afb206d07cffa4->leave($__internal_8d8a245f3c7db659dbc8542f8b70a57bd0e2ec0a1036bc93e8afb206d07cffa4_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_89e9d4540945f54f4d5ddbca880db0d2b2c7669594d28a23466961aaf00115fc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_89e9d4540945f54f4d5ddbca880db0d2b2c7669594d28a23466961aaf00115fc->enter($__internal_89e9d4540945f54f4d5ddbca880db0d2b2c7669594d28a23466961aaf00115fc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_d23fe3f125778ed98736b6cbb6593bb875bb95669407fc3e89b72fcfd5af516e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d23fe3f125778ed98736b6cbb6593bb875bb95669407fc3e89b72fcfd5af516e->enter($__internal_d23fe3f125778ed98736b6cbb6593bb875bb95669407fc3e89b72fcfd5af516e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "
    <div class=\"container\">
        <div class=\"row\">
            <h1>
                <span>Picture creation</span>
                <a href=\"";
        // line 9
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_index");
        echo "\" class=\"btn btn-default pull-right d-inline-block\">Back to the list</a>
            </h1>
            <br>

            ";
        // line 13
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 13, $this->getSourceContext()); })()), 'form_start');
        echo "
            ";
        // line 14
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 14, $this->getSourceContext()); })()), 'widget');
        echo "

            <button type=\"submit\" class=\"btn btn-primary d-inline\">Create</button>
            ";
        // line 17
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 17, $this->getSourceContext()); })()), 'form_end');
        echo "

        </div>
    </div>
";
        
        $__internal_d23fe3f125778ed98736b6cbb6593bb875bb95669407fc3e89b72fcfd5af516e->leave($__internal_d23fe3f125778ed98736b6cbb6593bb875bb95669407fc3e89b72fcfd5af516e_prof);

        
        $__internal_89e9d4540945f54f4d5ddbca880db0d2b2c7669594d28a23466961aaf00115fc->leave($__internal_89e9d4540945f54f4d5ddbca880db0d2b2c7669594d28a23466961aaf00115fc_prof);

    }

    // line 23
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_e3eeebfa533acc6d6f23facead15fbedea2f79211d8da37873b70308f08895ed = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e3eeebfa533acc6d6f23facead15fbedea2f79211d8da37873b70308f08895ed->enter($__internal_e3eeebfa533acc6d6f23facead15fbedea2f79211d8da37873b70308f08895ed_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_8ffd65c60852e22ba5311ac2b6ba4c4a760958a1d5d29143325841a8cb81d8ad = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8ffd65c60852e22ba5311ac2b6ba4c4a760958a1d5d29143325841a8cb81d8ad->enter($__internal_8ffd65c60852e22ba5311ac2b6ba4c4a760958a1d5d29143325841a8cb81d8ad_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 24
        echo "    <script>
        \$(document).ready(function() {
            \$(':input[type=\"submit\"]').prop('disabled', true);
        });


        \$('#appbundle_picture_imageFile_file').bind('change', function() {

            var sFileName = this.files[0].name;
            var sFileExtension = sFileName.split('.')[sFileName.split('.').length - 1].toLowerCase();
            var iFileSize = this.files[0].size;

            if (!(sFileExtension === \"jpg\" || sFileExtension === \"jpeg\" || sFileExtension === \"png\") || iFileSize > 1048576)
                \$(':input[type=\"submit\"]').prop('disabled', true);
            else
                \$(':input[type=\"submit\"]').prop('disabled', false);
        });
    </script>
";
        
        $__internal_8ffd65c60852e22ba5311ac2b6ba4c4a760958a1d5d29143325841a8cb81d8ad->leave($__internal_8ffd65c60852e22ba5311ac2b6ba4c4a760958a1d5d29143325841a8cb81d8ad_prof);

        
        $__internal_e3eeebfa533acc6d6f23facead15fbedea2f79211d8da37873b70308f08895ed->leave($__internal_e3eeebfa533acc6d6f23facead15fbedea2f79211d8da37873b70308f08895ed_prof);

    }

    public function getTemplateName()
    {
        return "picture/new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  98 => 24,  89 => 23,  74 => 17,  68 => 14,  64 => 13,  57 => 9,  50 => 4,  41 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}

    <div class=\"container\">
        <div class=\"row\">
            <h1>
                <span>Picture creation</span>
                <a href=\"{{ path('_index') }}\" class=\"btn btn-default pull-right d-inline-block\">Back to the list</a>
            </h1>
            <br>

            {{ form_start(form) }}
            {{ form_widget(form) }}

            <button type=\"submit\" class=\"btn btn-primary d-inline\">Create</button>
            {{ form_end(form) }}

        </div>
    </div>
{% endblock %}

{% block javascripts %}
    <script>
        \$(document).ready(function() {
            \$(':input[type=\"submit\"]').prop('disabled', true);
        });


        \$('#appbundle_picture_imageFile_file').bind('change', function() {

            var sFileName = this.files[0].name;
            var sFileExtension = sFileName.split('.')[sFileName.split('.').length - 1].toLowerCase();
            var iFileSize = this.files[0].size;

            if (!(sFileExtension === \"jpg\" || sFileExtension === \"jpeg\" || sFileExtension === \"png\") || iFileSize > 1048576)
                \$(':input[type=\"submit\"]').prop('disabled', true);
            else
                \$(':input[type=\"submit\"]').prop('disabled', false);
        });
    </script>
{% endblock %}", "picture/new.html.twig", "C:\\Users\\Public\\Desktop\\online_gallery (Symfony 3 server side)\\app\\Resources\\views\\picture\\new.html.twig");
    }
}
